#'
#' aDRG_DEA_results dataset
#'
#' DESeq2 test results dataframe of bulk RNA extracted from mouse dorsal root ganglion neurons of Tmem184b-mutant and Wild-Type (C57BL/6) mice
#'
#' @docType data
#' @format one of 3 datasets for the package to test and execute package functions:
#' \describe{
#'    \item{GeneID}{Entrez gene identifiers for mus musculus build 9; character}
#'    \item{Base.Mean}{average of normalized counts estimate across all samples; double}
#'    \item{log2.FC}{the ratio of group-wise average expression (target (Mutant) sample average : control (Wild-Type) sample average) then transformed by log-base 2; double}
#'    \item{stdError}{standard error of the estimated mean expression value; double}
#'    \item{Wald.stats}{Wald test statistic; double}
#'    \item{Pval}{P-value having computed a Wald test statistic; double}
#'    \item{AdjP}{adjusted P-value, correcting for multiple tests using the Benjamini-Hochberg method; character}
#'    \item{\%WT}{expression level in the target group (Mutant) relative to the control (Wild-Type), expressed as a percent of control expression; double}
#'    }
#'
#' @details
#' Additional manipulations on the data were made to exclude pseudogenes, unannotated genes, ribosomal genes, and genes not containing an adjusted P-value.
#' These manipulations were as follows:
#' \code{
#' library(readxl)
#' read_xlsx('path_to_file_from_source/NIHMS1770888-supplement-SDC_1_-_Adult_DRG_RNAseq.xlsx') |>
#'  dplyr::rename(Base.Mean = `Base Mean`,
#'                log2.FC = `log2(FC)`,
#'                Wald.stats = `Wald stats`,
#'                `\%WT` = `\% WT`) |>
#'  dplyr::filter(!is.na(AdjP)) |>
#'  dplyr::filter(!grepl(GeneID,
#'                        pattern = 'Rps.+.?$|Rpl.+.?$|MRPL.+.?$|Mrpl.+.?$|MRPS.+.?$|Mrps.+.?$|.*Rik.+$|Gm.+.?$|^[A-Z+]+[A-Z].+.?$|^[0-9]+.+.?$|mt.+.?$')) |>
#'  dplyr::filter(is.na(`...9`)) |> # removes Nppb which we noted as having been excluded by DESeq2 because of persistently low expression across mutant samples
#'  dplyr::select(c(1:8))
#' }
#'
#' @source [TMEM184B is necessary for IL-31-induced itch](https://pmc.ncbi.nlm.nih.gov/articles/PMC8854445/#SD5)
#' @references [DESeq2 Paper](https://genomebiology.biomedcentral.com/articles/10.1186/s13059-014-0550-8)
#'
"aDRG_DEA_results"
